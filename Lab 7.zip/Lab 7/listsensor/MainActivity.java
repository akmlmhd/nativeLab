package com.example.listsensor;

import androidx.appcompat.app.AppCompatActivity;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    // Declare SensorManager
    private SensorManager senseMan;

    // Declare ListView
    private ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Map lv to resource lv
        lv = (ListView)findViewById(R.id.listView);

        // Get sensor manager
        senseMan = (SensorManager)getSystemService(SENSOR_SERVICE);

        // Get sensor list and put inside ArrayList
        List<Sensor> sensorList = senseMan.getSensorList(Sensor.TYPE_ALL);

        // Put the sensor list into ListView
        lv.setAdapter(new ArrayAdapter<Sensor>(this, android.R.layout.simple_list_item_1, sensorList));
    }
}
