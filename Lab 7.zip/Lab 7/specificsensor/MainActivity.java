package com.example.specificsensor;

// MainActivity.java
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager senseMan;
    private Sensor lightSensor;
    private Sensor proximitySensor;
    private Sensor humiditySensor;

    private TextView lightTextView;
    private TextView proximityTextView;
    private TextView humidityTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Map textviews to TextView resources
        lightTextView = findViewById(R.id.lightTextView);
        proximityTextView = findViewById(R.id.proximityTextView);
        humidityTextView = findViewById(R.id.humidityTextView);

        // Map sensor manager to system service
        senseMan = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        // Map sensors to their respective types
        lightSensor = senseMan.getDefaultSensor(Sensor.TYPE_LIGHT);
        proximitySensor = senseMan.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        humiditySensor = senseMan.getDefaultSensor(Sensor.TYPE_RELATIVE_HUMIDITY);

        // Register listeners for sensors
        registerSensor(lightSensor, "Light sensor");
        registerSensor(proximitySensor, "Proximity sensor");
        registerSensor(humiditySensor, "Relative Humidity sensor");
    }

    private void registerSensor(Sensor sensor, String sensorName) {
        if (sensor != null) {
            senseMan.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL);
            Toast.makeText(this, sensorName + " found", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, sensorName + " not found", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        // Update the respective TextViews based on sensor type
        switch (event.sensor.getType()) {
            case Sensor.TYPE_LIGHT:
                lightTextView.setText("Light Level: " + event.values[0]);
                break;
            case Sensor.TYPE_PROXIMITY:
                proximityTextView.setText("Proximity: " + event.values[0]);
                break;
            case Sensor.TYPE_RELATIVE_HUMIDITY:
                humidityTextView.setText("Relative Humidity: " + event.values[0]);
                break;
            // Add more cases for other sensor types if needed
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Implement if needed
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Register listeners for sensors in onResume
        registerSensor(lightSensor, "Light sensor");
        registerSensor(proximitySensor, "Proximity sensor");
        registerSensor(humiditySensor, "Relative Humidity sensor");
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Unregister listeners for sensors in onPause
        senseMan.unregisterListener(this);
    }
}

