package com.example.businesscard

/*
Muhammad Akmal Bin Zainal Abdin
S62734
 */
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Border
import com.example.businesscard.ui.theme.BusinessCardTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BusinessCardTheme {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Gray) // Set the background color to gray for the entire screen
                ) {
                    // Call your custom Composable function here
                    BusinessCard()
                }
            }
        }
    }
}

@Composable
fun BusinessCard() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.android_icon),
                contentDescription = null, // Set contentDescription to null for decorative images
                modifier = Modifier
                    .size(96.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Akmal",
                style = MaterialTheme.typography.headlineSmall,
                fontSize = 24.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Mobile Developer",
                style = MaterialTheme.typography.bodyLarge,
                fontSize = 16.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            Column {
                ContactItem("Phone: +60 13-3664295", Color.White)
                ContactItem("Email: akmal23a@gmail.com", Color.White)
                ContactItem("Instagram: @_akmlmhd", Color.White)
            }
        }
    }
}

@Composable
fun ContactItem(text: String, textColor: Color = Color.Black) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 4.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            fontSize = 14.sp,
            color = textColor
        )
    }
}