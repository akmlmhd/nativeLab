package com.example.recipes

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.recipes.data.Datasource
import com.example.recipes.model.Recipe
import com.example.recipes.ui.theme.RecipesTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RecipesTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    RecipesApp()
                }
            }
        }
    }
}

@Composable
fun RecipesApp() {
    RecipeList(
        recipeList = Datasource().loadRecipes(),
    )
}

@Composable
fun RecipeList(recipeList: List<Recipe>, modifier: Modifier = Modifier) {
    LazyColumn(modifier = modifier) {
        items(recipeList) { recipe ->
            RecipeCard(
                recipe = recipe,
                modifier = Modifier.padding(8.dp)
            )
        }
    }
}


@Composable
fun RecipeCard(recipe: Recipe, modifier: Modifier = Modifier) {
    var expanded by remember { mutableStateOf(false) }

    Card(modifier = modifier) {
        Column {
            Text(
                text = recipe.day,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                style = MaterialTheme.typography.headlineSmall
            )
            Text(
                text = recipe.title,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                style = MaterialTheme.typography.headlineSmall
            )
            // Integrate the Box for expansion
            Box(
                modifier = Modifier
                    .animateContentSize()
                    .fillMaxWidth()
                    .height(if (expanded) 400.dp else 200.dp)
                    .background(MaterialTheme.colorScheme.background)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        expanded = !expanded
                    }
            ) {
                // Column layout for stacking Image and Text vertically
                Column {
                    // Image with clickable modifier
                    Image(
                        painter = painterResource(recipe.imageResourceId),
                        contentDescription = stringResource(recipe.stringResourceId),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(194.dp)
                        .clickable {
                                expanded = !expanded
                            },
                        contentScale = ContentScale.Crop
                    )

                    // Description text with conditional visibility
                    if (expanded) {
                        Text(
                            text = LocalContext.current.getString(recipe.stringResourceId),
                            modifier = Modifier.padding(16.dp),
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }

        }
    }
}


@Preview
@Composable
private fun RecipeCardPreview() {
    RecipeCard(Recipe(R.string.recipe1, R.drawable.image1, title = "Nasi Lemak", day = "Day 1"))
}


