package com.example.recipes.data

import com.example.recipes.R
import com.example.recipes.model.Recipe

/**
 * [Datasource] generates a list of [Recipe]
 */
class Datasource() {
    fun loadRecipes(): List<Recipe> {
        return listOf(
            Recipe(R.string.recipe1, R.drawable.image1, "Nasi Lemak", "Day 1"),
            Recipe(R.string.recipe2, R.drawable.image2, "Nasi Ayam", "Day 2"),
            Recipe(R.string.recipe3, R.drawable.image3, "Bakso", "Day 3"),
            Recipe(R.string.recipe4, R.drawable.image4, "Mi Kari", "Day 4"),
            Recipe(R.string.recipe5, R.drawable.image5, "Nasi Kukus Ayam Berempah", "Day 5")
        )
    }
}
