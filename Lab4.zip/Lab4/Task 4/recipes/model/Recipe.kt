package com.example.recipes.model

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

/**
 * [Recipe] is the data class to represent the Affirmation text and imageResourceId
 */
data class Recipe(
    val stringResourceId: Int,
    val imageResourceId: Int,
    val title: String,
    val day: String
)

