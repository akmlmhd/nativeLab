package com.example.phonemessaging;

import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * Uses an implicit intent to dial the phone with the Phone app.
     * Gets the phone number from TextView number_to_call.
     *
     * @param view View (phone_icon) that was clicked.
     */
    public void dialNumber(View view) {
        TextView textView = findViewById(R.id.number_to_call);
        String phoneNumber = String.format("tel: %s", textView.getText().toString());
        Intent dialIntent = new Intent(Intent.ACTION_DIAL, Uri.parse(phoneNumber));
        startActivity(dialIntent);
    }

    /**
     * Uses an implicit intent to send a message with an SMS messaging app.
     * Gets the phone number from TextView number_to_call.
     *
     * @param view View (message_icon) that was clicked.
     */
    public void smsSendMessage(View view) {
        TextView textView = (TextView) findViewById(R.id.number_to_call);
        // Use format with "smsto:" and phone number to create smsNumber.
        String smsNumber = String.format("smsto: %s", textView.getText().toString());
        // Find the sms_message view.
        EditText smsEditText = (EditText) findViewById(R.id.sms_message);
        // Get the text of the sms message.
        String sms = smsEditText.getText().toString();
        // Create the intent.
        Intent smsIntent = new Intent(Intent.ACTION_SENDTO);
        // Set the data for the intent as the phone number.
        smsIntent.setData(Uri.parse(smsNumber));
        // Add the message (sms) with the key ("sms_body").
        smsIntent.putExtra("sms_body", sms);
        // If package resolves to an app, send intent.
        if (smsIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(smsIntent);
        } else {
            Log.e(TAG, "Can't resolve app for ACTION_SENDTO Intent.");
        }
    }






}