package com.example.loginpreference;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        if (isUserLoggedIn()) {
            // User is logged in, open success activity
            startActivity(new Intent(this, SuccessActivity.class));
        } else {
            // User is not logged in, open login activity
            startActivity(new Intent(this, LoginActivity.class));
        }

        finish();
    }

    private boolean isUserLoggedIn() {
        String username = sharedPreferences.getString("username", null);
        String password = sharedPreferences.getString("password", null);

        // For simplicity, you can check if both username and password are present.
        return username != null && password != null && !username.isEmpty() && !password.isEmpty();
    }
}

