package com.example.loginpreference;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SuccessActivity extends AppCompatActivity {

    EditText etUsername,etPassword;
    Button clear, get;
    SharedPreferences sp ;

    public static final String keyusername="username";
    public static final String keypassword="password";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_success);

        etUsername=findViewById(R.id.etUsername);
        etPassword=findViewById(R.id.etPassword);

        clear=findViewById(R.id.button);
        get = findViewById(R.id.button2);

        sp = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor =sp.edit();
                editor.clear();
                editor.commit();
                Toast.makeText(SuccessActivity.this,"Data is Deleted", Toast.LENGTH_LONG).show();

            }
        });

        get.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sp.getAll().isEmpty()){
                    Toast.makeText(SuccessActivity.this,"Shared Preference is Empty", Toast.LENGTH_LONG).show();
                }else {
                    String username=sp.getString(keyusername,"");
                    String password=sp.getString(keypassword,"");

                    etUsername.setText(username.toString());
                    etPassword.setText(password.toString());
                }

            }
        });
    }
}

